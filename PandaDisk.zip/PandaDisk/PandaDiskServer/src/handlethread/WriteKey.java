package handlethread;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.FileOutputStream;
public class WriteKey {
	public static boolean write(String txtPath,String content){    
	       FileOutputStream fileOutputStream = null;
	       File file = new File(txtPath);
	       try {
	           if(file.exists()){
	               //�ж��ļ��Ƿ���ڣ���������ھ��½�һ��txt
	               file.createNewFile();
	           }
	           fileOutputStream = new FileOutputStream(file);
	           fileOutputStream.write(content.getBytes());
	           fileOutputStream.flush();
	           fileOutputStream.close();
	           return true;
	       } catch (Exception e) {
	           e.printStackTrace();
	           return false;
	       }
	}
	/*public static boolean write(String emk,String fn)
	{
		File file = new File(fn+".txt");
		try
		{
			FileWriter filewriter = new FileWriter(file); 
			BufferedWriter bw = new BufferedWriter(filewriter);
			bw.write(emk + "\r\n");
			bw.close();
			filewriter.close();
			return true;
		} catch (Exception e1)
		{
			e1.printStackTrace();
		}
		return false;
	}*/
}
