import java.util.HashMap;

public class UserInfo implements Runnable
{
	String Nickname = null;
	String UsedAmount = null;
	String TotalAmount = null;
	String Percent = null;
	MainWindow mainwindow = null;
	String EnMasterkey=null;//***c 
	String Mail=null;//***c 
	String PWKey=null;//***c
	String Masterkey=null;//***c
	public UserInfo(MainWindow mainwindow,String data) throws Exception
	{
		HashMap<String,String> map = MapString.StringToMap(data);
		Nickname = map.get("Nickname");
		UsedAmount = map.get("UsedCapacity");
		TotalAmount = map.get("TotalCapacity");
		Percent = map.get("Percent");
		//��ȡ����Կ��������Կ��������Կ��д���ļ���
		EnMasterkey=map.get("EnMasterkey");//***c
		PWKey=ReadKey.read("pwkey");
		Masterkey=AES.decrypt1(EnMasterkey, PWKey);
		WriteKey.write(Masterkey, "masterkey");
		this.mainwindow = mainwindow;
	}
	public void run()
	{
		mainwindow.Nickname.setText(Nickname);
		mainwindow.SetCapacity(UsedAmount, TotalAmount, Integer.valueOf(Percent));
	}
}
