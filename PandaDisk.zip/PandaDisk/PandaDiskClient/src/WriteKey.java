import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;

public class WriteKey {
	public static boolean write(String emk,String fn)
	{
		File file = new File(fn+".txt");
		try
		{
			if(file.exists())file.delete();
			FileWriter filewriter = new FileWriter(file); 
			BufferedWriter bw = new BufferedWriter(filewriter);
			bw.write(emk + "\r\n");
			bw.close();
			filewriter.close();
			return true;
		} catch (Exception e1)
		{
			e1.printStackTrace();
		}
		return false;
	}
}
