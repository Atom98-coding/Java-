import java.security.AlgorithmParameters;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchProviderException;
import java.security.Security;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Base64.Encoder;

public class AESCBC{

	//���ܷ�ʽ
    public static String KEY_ALGORITHM = "AES";
    //������䷽ʽ
    //String algorithmStr = "AES/CBC/PKCS5Padding";

    /**
     * 
     * @param originalContent
     * @param encryptKey
     * @param ivByte
     * @return
     */
    public static byte[] encrypt(byte[] originalContent, byte[] encryptKey, byte[] ivByte) {
        try {
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            SecretKeySpec skeySpec = new SecretKeySpec(encryptKey, "AES");
            cipher.init(Cipher.ENCRYPT_MODE, skeySpec, generateIV(ivByte));
            byte[] encrypted = cipher.doFinal(originalContent);
            Encoder encoder = Base64.getEncoder();
            byte[] strs = encoder.encode(encrypted);
            return strs;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * AES����
     * ���ģʽAES/CBC/PKCS5Padding
     * ����ģʽ128
     * @param content
     *            Ŀ������
     * @return
     * @throws Exception 
     * @throws InvalidKeyException 
     * @throws NoSuchProviderException
     */
    public static byte[] decrypt(byte[] content, byte[] DecryptKey, byte[] ivByte) {
        try {
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            Key sKeySpec = new SecretKeySpec(DecryptKey, "AES");
            cipher.init(Cipher.DECRYPT_MODE, sKeySpec, generateIV(ivByte));// ��ʼ��
            Decoder decoder = Base64.getDecoder();
            byte[] res = decoder.decode(content);
            res = cipher.doFinal(res);  
            return res;  
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    // ����iv
    public static AlgorithmParameters generateIV(byte[] iv) throws Exception {
        AlgorithmParameters params = AlgorithmParameters.getInstance("AES");
        params.init(new IvParameterSpec(iv));
        return params;
    }
}


