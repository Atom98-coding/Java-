import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.util.HashMap;
import java.security.*;

public class Upload implements Runnable
{
	String data = null;
	String InitIv=null;
	String EncodeIv=null;
	String masterkey=null;
	public static String generateRandom(int length){

        SecureRandom random = new SecureRandom(); 

        byte[] randomBytes = new byte[length];

        random.nextBytes(randomBytes);

       StringBuilder sb = new StringBuilder(length);

        for (byte b : randomBytes) {

           sb.append( Math.abs(Byte.valueOf(b).intValue())%10);

        }

        return sb.toString();

    }
	public Upload(String Username,String Route,String RemoteRoute)
	{
		HashMap<String,String> map = new HashMap<>();
		map.put("Mark", "Upload");
		map.put("Username",Username);
		map.put("Route", Route);
		map.put("RemoteRoute", RemoteRoute);//�������ļ�·��
		File file = new File(Route);//�ͻ����ļ�·��
		map.put("Filename", file.getName());
		map.put("FileSize", GetSize(file));
		InitIv=generateRandom(16);
		System.out.println("��ʼ����iv"+InitIv);
		System.out.println("��ʼ����iv"+InitIv.length());
		
		masterkey=ReadKey.read("masterkey");
		try {
			EncodeIv=InitIv;
			//EncodeIv=AES.encrypt1(InitIv, masterkey);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		map.put("iv",EncodeIv);
		System.out.println("����iv"+EncodeIv);
		System.out.println("����iv"+EncodeIv.length());
		
		WriteKey.write(InitIv,file.getName());
		//�����ļ�hashֵ
		try
		{
			FileInputStream in ;
			if(GetSize(file).equals("-"))
			{
				   String zipname=Route+".zip";
				   File[] files = new File[]{new File(Route)};  
			        File zip = new File(zipname);  
			        conzip tempzip=new conzip();
			        try {
						tempzip.ZipFiles(zip,"",files);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}  
			        in= new FileInputStream(zip);
			}
			else
				in = new FileInputStream(file);
			MessageDigest md5 = MessageDigest.getInstance("MD5");
			//FileInputStream in = new FileInputStream(file);
			int length = 0;
			byte [] buffer = new byte[1024];
			while((length = in.read(buffer)) != -1)//��ȡ�ļ���������
				md5.update(buffer);
			String FileHash = new String(bytes2hex(md5.digest()));
			map.put("FileHash", FileHash);
		} catch (Exception e)
		{
			e.printStackTrace();
		}
		
		data = MapString.MapToString(map);
	}
	public void run()
	{
		Send.send(data);
	}
	private String GetSize(File file)
	{
		double FileSize = 0;
		String Filesize = null;
		if(file.isDirectory())//������ļ���
			Filesize = "-";
		else if(file.length() < 1024) // < 1KB
		{
			FileSize = (double)Math.round(file.length()*100)/100;
			Filesize =  FileSize + " B";
		}
		else if(file.length() > 1024 && file.length() < 1024 * 1024)// >1KB <1MB
		{
			FileSize = (double)Math.round(file.length() / (double)1024*100)/100;
			Filesize = FileSize + " KB";
		}
		else if(file.length() > 1024 * 1024 && 
				file.length() < 1024 * 1024 * 1024)// >1MB <1GB
		{
			FileSize = (double)Math.round(file.length() / (double)(1024 *1024)*100)/100;
			Filesize =  FileSize + " MB";
		}
		else
		{
			FileSize = (double)Math.round(file.length() / (double)(1024 *1024*1024)*100)/100;
			Filesize =  FileSize + " GB";
		}
		return Filesize;
	}
	 public static String bytes2hex(byte[] bytes)  
	    {  
	        /** 
	         * ��һ�������Ľ��ͣ��ǵ�һ��Ҫ����Ϊ1 
	         *  signum of the number (-1 for negative, 0 for zero, 1 for positive). 
	         */  
	        BigInteger bigInteger = new BigInteger(1, bytes);  
	        return bigInteger.toString(16);  
	    }  
}
