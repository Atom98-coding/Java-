import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

public class ReadKey {

	public static String read(String fn)
	{
		try
		{
			File file = new File(fn+".txt");
			FileReader filereader = new FileReader(file);
			BufferedReader br = new BufferedReader(filereader);
			String key = null;
			key = br.readLine();
			if(key == null || key.isEmpty())
			{
				br.close();
				System.out.println(fn+":δ�ҵ���Կ");
				return null;
			}
			return key;
		}catch (Exception e1)
		{
			return null;
		}
	}
}
